package com.jspxcms.common.file;

public interface CommonFileFilter {
	boolean accept(CommonFile file);
}

package com.jspxcms.common.web;

/**
 * 分页url获取接口
 * 
 * @author liufang
 * 
 */
public interface PageUrlResolver {
	public String getPageUrl(Integer page);
}

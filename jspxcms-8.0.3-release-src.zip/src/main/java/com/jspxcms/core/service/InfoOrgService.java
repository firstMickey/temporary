package com.jspxcms.core.service;

import com.jspxcms.core.domain.Info;

public interface InfoOrgService {
	public void update(Info info, Integer[] viewOrgIds);
}

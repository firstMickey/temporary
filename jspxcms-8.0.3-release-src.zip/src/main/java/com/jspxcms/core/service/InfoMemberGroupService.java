package com.jspxcms.core.service;

import com.jspxcms.core.domain.Info;

public interface InfoMemberGroupService {
	public void update(Info info, Integer[] viewGroupIds);
}

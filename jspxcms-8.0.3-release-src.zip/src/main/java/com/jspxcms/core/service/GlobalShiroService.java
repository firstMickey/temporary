package com.jspxcms.core.service;

import com.jspxcms.core.domain.Global;

/**
 * GlobalShiroService
 * 
 * @author liufang
 * 
 */
public interface GlobalShiroService {
	public Global findUnique();

}

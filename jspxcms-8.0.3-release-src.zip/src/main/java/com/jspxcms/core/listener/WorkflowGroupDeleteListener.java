package com.jspxcms.core.listener;

/**
 * WorkflowGroupDeleteListener
 * 
 * @author liufang
 * 
 */
public interface WorkflowGroupDeleteListener {
	public void preWorkflowGroupDelete(Integer[] ids);
}

package com.jspxcms.core.listener;

/**
 * ModelDeleteListener
 * 
 * @author liufang
 * 
 */
public interface ModelDeleteListener {
	public void preModelDelete(Integer[] ids);
}

package com.jspxcms.core.listener;

/**
 * ScoreItemDeleteListener
 * 
 * @author liufang
 * 
 */
public interface ScoreItemDeleteListener {
	public void preScoreItemDelete(Integer[] ids);
}

package com.jspxcms.core.listener;

/**
 * SpecialCategoryDeleteListener
 * 
 * @author liufang
 * 
 */
public interface SpecialCategoryDeleteListener {
	public void preSpecialCategoryDelete(Integer[] ids);
}

package com.jspxcms.core.listener;

/**
 * WorkflowStepDeleteListener
 * 
 * @author liufang
 * 
 */
public interface WorkflowStepDeleteListener {
	public void preWorkflowStepDelete(Integer[] ids);
}

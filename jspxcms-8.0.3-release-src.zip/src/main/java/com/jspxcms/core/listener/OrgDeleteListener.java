package com.jspxcms.core.listener;

/**
 * OrgDeleteListener
 * 
 * @author liufang
 * 
 */
public interface OrgDeleteListener {
	public void preOrgDelete(Integer[] ids);
}

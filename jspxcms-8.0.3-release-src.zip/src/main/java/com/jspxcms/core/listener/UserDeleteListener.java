package com.jspxcms.core.listener;

/**
 * UserDeleteListener
 * 
 * @author liufang
 * 
 */
public interface UserDeleteListener {
	public void preUserDelete(Integer[] ids);
}

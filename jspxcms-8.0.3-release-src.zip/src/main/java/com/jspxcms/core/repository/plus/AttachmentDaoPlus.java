package com.jspxcms.core.repository.plus;

public interface AttachmentDaoPlus {

}

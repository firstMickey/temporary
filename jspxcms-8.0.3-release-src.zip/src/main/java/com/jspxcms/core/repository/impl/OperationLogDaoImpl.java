package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.OperationLogDaoPlus;

public class OperationLogDaoImpl implements OperationLogDaoPlus {

}

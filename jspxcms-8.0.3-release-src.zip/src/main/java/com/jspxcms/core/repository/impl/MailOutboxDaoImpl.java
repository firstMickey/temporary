package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.MailOutboxDaoPlus;

public class MailOutboxDaoImpl implements MailOutboxDaoPlus {

}

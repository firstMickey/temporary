package com.jspxcms.core.repository.impl;

import com.jspxcms.core.repository.plus.TaskDaoPlus;

public class TaskDaoImpl implements TaskDaoPlus {

}

package com.jspxcms.core.repository.impl;

public class MailTextDaoImpl {

}
